#include<iostream>
using namespace std;

class Convert
{
int n;
int *number = new int[n];

public:
string encode(string s, int j)
{
n = s.length();
for(int i=0; i<n; i++)
{
number[i] = (int)s[i];
}

for(int i=j; i<s.length(); i = i+j)
{
number[i] = number[i] + 1;
}

for(int i=0; i<s.length(); i++)
{
s[i] = (char)number[i];
}

return s;

}


};


int main()
{
Convert con;
string s = "Sazim is mad";
int j = 2;
cout <<  con.encode(s,j) << endl;


return 0;
}
