

#include <iostream>
using namespace std;
int main()
{
  int n;
  cout<<"Enter Length of Elements = ";
  cin>>n;
  int arr[10];
  for(int i=0;i<n;i++)
  {
      cout<<"Enter Number = ";
      cin>>arr[i];
  }

  int counter[10];
  for(int i=0; i<n; i++)
    counter[i]=0;


    int tempcount;

    for(int i=0; i<n; i++)
    {
        tempcount = 1;
        for(int j=i+1; j<n; j++)
        {

            if(arr[i]==arr[j])
            {

            tempcount++;


                counter[j] = 1;
            }
        }


        if(counter[i] != 1)
            counter[i] = tempcount;
    }

    for(int i=0; i<n; i++)
    {
        if(counter[i] != 0)
            printf("%d OCCURED = %d times.\n", arr[i], counter[i]);
    }
 return 0;
}
