#include <iostream>
using namespace std;

class TwoDArray
{

    int oldArray[3][4]
    {
        {1,6,7,9},
        {2,4,8,5},
        {3,1,9,4}

    };

    int newArray[3][4];

public:

    void transpose ()
    {
        for(int i=0; i<3; i++)
        {
            for(int j=0; j<4; j++)
            {
                newArray[j][i]  = oldArray[i][j];
            }
        }
        printNewArray();
    }

    void printNewArray()
    {

        for(int i=0; i<4; i++)
        {
            for(int j=0; j<3; j++)
            {
                cout<<newArray[i][j]<< " ";
            }
            cout<<endl;
        };
        return;
    }


    void printOldArray()
    {

        for(int i=0; i<3; i++)
        {
            for(int j=0; j<4; j++)
            {
                cout<<oldArray[i][j]<< " ";
            }
            cout<<endl;
        };
        return;
    }
};


int main()
{
    TwoDArray arr;
    arr.printOldArray();
    cout<<"---------"<<endl;
    arr.transpose();
    return 0;
}